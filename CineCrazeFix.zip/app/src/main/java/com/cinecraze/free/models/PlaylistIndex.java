package com.cinecraze.free.models;

import java.util.List;

public class PlaylistIndex {
    private List<String> playlists;

    public List<String> getPlaylists() {
        return playlists;
    }
}
