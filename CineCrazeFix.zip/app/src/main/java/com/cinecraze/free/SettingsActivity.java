package com.cinecraze.free;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;

public class SettingsActivity extends AppCompatActivity {

    private static final String PREFS_NAME = "ParentalControls";
    private static final String PIN_KEY = "pin";
    private static final String RATING_KEY = "rating";
    private static final String UNRATED_KEY = "unrated";

    private SharedPreferences prefs;
    private EditText pinEditText;
    private Button savePinButton;
    private Spinner ratingSpinner;
    private SwitchCompat unratedSwitch;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);

        pinEditText = findViewById(R.id.pin_edit_text);
        savePinButton = findViewById(R.id.save_pin_button);
        ratingSpinner = findViewById(R.id.rating_spinner);
        unratedSwitch = findViewById(R.id.unrated_switch);

        setupRatingSpinner();

        if (isPinSet()) {
            promptForPin();
        } else {
            showSettings();
        }
    }

    private boolean isPinSet() {
        return prefs.contains(PIN_KEY);
    }

    private void promptForPin() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Enter PIN");

        View dialogView = getLayoutInflater().inflate(R.layout.dialog_pin_entry, null);
        final EditText input = dialogView.findViewById(R.id.pin_input);
        builder.setView(dialogView);

        builder.setPositiveButton("OK", (dialog, which) -> {
            String enteredPin = input.getText().toString();
            if (checkPin(enteredPin)) {
                showSettings();
            } else {
                Toast.makeText(this, "Incorrect PIN", Toast.LENGTH_SHORT).show();
                finish();
            }
        });
        builder.setNegativeButton("Cancel", (dialog, which) -> {
            dialog.cancel();
            finish();
        });

        builder.show();
    }

    private boolean checkPin(String enteredPin) {
        String savedPin = prefs.getString(PIN_KEY, null);
        return enteredPin.equals(savedPin);
    }

    private void showSettings() {
        loadSettings();

        savePinButton.setOnClickListener(v -> {
            String newPin = pinEditText.getText().toString();
            if (newPin.length() == 4) {
                savePin(newPin);
                Toast.makeText(this, "PIN saved", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "PIN must be 4 digits", Toast.LENGTH_SHORT).show();
            }
        });

        ratingSpinner.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(android.widget.AdapterView<?> parent, View view, int position, long id) {
                saveRating(parent.getItemAtPosition(position).toString());
            }

            @Override
            public void onNothingSelected(android.widget.AdapterView<?> parent) {
            }
        });

        unratedSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            saveUnratedSetting(isChecked);
        });
    }

    private void loadSettings() {
        String savedRating = prefs.getString(RATING_KEY, "G");
        int spinnerPosition = ((ArrayAdapter<String>) ratingSpinner.getAdapter()).getPosition(savedRating);
        ratingSpinner.setSelection(spinnerPosition);

        boolean showUnrated = prefs.getBoolean(UNRATED_KEY, true);
        unratedSwitch.setChecked(showUnrated);
    }

    private void savePin(String pin) {
        SharedPreferences.Editor editor = prefs.edit();
        editor.putString(PIN_KEY, pin);
        editor.apply();
    }

    private void saveRating(String rating) {
        SharedPreferences.Editor editor = prefs.edit();
        editor.putString(RATING_KEY, rating);
        editor.apply();
    }

    private void saveUnratedSetting(boolean showUnrated) {
        SharedPreferences.Editor editor = prefs.edit();
        editor.putBoolean(UNRATED_KEY, showUnrated);
        editor.apply();
    }

    private void setupRatingSpinner() {
        String[] ratings = new String[]{"G", "PG", "PG-13", "R", "NC-17"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, R.layout.spinner_item, ratings);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        ratingSpinner.setAdapter(adapter);
    }
}
