package com.cinecraze.free;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class SettingsActivity extends AppCompatActivity {

    private boolean settingsChanged = false;
    private static final String PREFS_NAME = "ParentalControls";
    private static final String PIN_KEY = "pin";
    private static final String SELECTED_RATINGS_KEY = "selected_ratings";
    private static final String UNRATED_KEY = "unrated";

    private SharedPreferences prefs;
    private EditText pinEditText;
    private Button savePinButton;
    private TextView selectedRatingsTextView;
    private SwitchCompat unratedSwitch;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);

        pinEditText = findViewById(R.id.pin_edit_text);
        savePinButton = findViewById(R.id.save_pin_button);
        selectedRatingsTextView = findViewById(R.id.selected_ratings_text_view);
        unratedSwitch = findViewById(R.id.unrated_switch);

        selectedRatingsTextView.setOnClickListener(v -> showMultiSelectRatingDialog());

        if (isPinSet()) {
            promptForPin();
        } else {
            showSettings();
        }
    }

    private boolean isPinSet() {
        return prefs.contains(PIN_KEY);
    }

    private void promptForPin() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Enter PIN");

        View dialogView = getLayoutInflater().inflate(R.layout.dialog_pin_entry, null);
        final EditText input = dialogView.findViewById(R.id.pin_input);
        builder.setView(dialogView);

        builder.setPositiveButton("OK", (dialog, which) -> {
            String enteredPin = input.getText().toString();
            if (checkPin(enteredPin)) {
                showSettings();
            } else {
                Toast.makeText(this, "Incorrect PIN", Toast.LENGTH_SHORT).show();
                finish();
            }
        });
        builder.setNegativeButton("Cancel", (dialog, which) -> {
            dialog.cancel();
            finish();
        });

        builder.show();
    }

    private boolean checkPin(String enteredPin) {
        String savedPin = prefs.getString(PIN_KEY, null);
        return enteredPin.equals(savedPin);
    }

    private void showSettings() {
        loadSettings();

        savePinButton.setOnClickListener(v -> {
            String newPin = pinEditText.getText().toString();
            if (newPin.length() == 4) {
                savePin(newPin);
                Toast.makeText(this, "PIN saved", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "PIN must be 4 digits", Toast.LENGTH_SHORT).show();
            }
        });

        unratedSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            saveUnratedSetting(isChecked);
        });
    }

    private void loadSettings() {
        Set<String> selectedRatings = prefs.getStringSet(SELECTED_RATINGS_KEY, new HashSet<>(Arrays.asList("G", "PG", "PG-13", "R", "NC-17")));
        updateSelectedRatingsTextView(selectedRatings);

        boolean showUnrated = prefs.getBoolean(UNRATED_KEY, true);
        unratedSwitch.setChecked(showUnrated);
    }

    private void savePin(String pin) {
        SharedPreferences.Editor editor = prefs.edit();
        editor.putString(PIN_KEY, pin);
        editor.apply();
    }

    private void saveRatings(Set<String> ratings) {
        SharedPreferences.Editor editor = prefs.edit();
        editor.putStringSet(SELECTED_RATINGS_KEY, ratings);
        editor.apply();
        settingsChanged = true;
    }

    private void saveUnratedSetting(boolean showUnrated) {
        SharedPreferences.Editor editor = prefs.edit();
        editor.putBoolean(UNRATED_KEY, showUnrated);
        editor.apply();
        settingsChanged = true;
    }

    @Override
    public void finish() {
        Intent resultIntent = new Intent();
        resultIntent.putExtra("settings_changed", settingsChanged);
        setResult(RESULT_OK, resultIntent);
        super.finish();
    }

    @Override
    public void onBackPressed() {
        // Overriding to ensure result is sent back
        finish();
    }

    private void updateSelectedRatingsTextView(Set<String> ratings) {
        if (ratings == null || ratings.isEmpty()) {
            selectedRatingsTextView.setText("Click to select ratings");
        } else {
            List<String> sortedRatings = new ArrayList<>(ratings);
            Collections.sort(sortedRatings);
            selectedRatingsTextView.setText(String.join(", ", sortedRatings));
        }
    }

    private void showMultiSelectRatingDialog() {
        String[] ratings = new String[]{"G", "PG", "PG-13", "R", "NC-17"};
        boolean[] checkedItems = new boolean[ratings.length];

        Set<String> selectedRatings = prefs.getStringSet(SELECTED_RATINGS_KEY, new HashSet<>(Arrays.asList("G", "PG", "PG-13", "R", "NC-17")));
        for (int i = 0; i < ratings.length; i++) {
            if (selectedRatings.contains(ratings[i])) {
                checkedItems[i] = true;
            }
        }

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Select Allowed Ratings");
        builder.setMultiChoiceItems(ratings, checkedItems, (dialog, which, isChecked) -> {
            checkedItems[which] = isChecked;
        });

        builder.setPositiveButton("OK", (dialog, which) -> {
            Set<String> newSelectedRatings = new HashSet<>();
            for (int i = 0; i < ratings.length; i++) {
                if (checkedItems[i]) {
                    newSelectedRatings.add(ratings[i]);
                }
            }
            saveRatings(newSelectedRatings);
            updateSelectedRatingsTextView(newSelectedRatings);
        });
        builder.setNegativeButton("Cancel", null);

        builder.show();
    }
}
